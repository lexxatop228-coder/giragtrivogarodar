/* Interface appearance is independent of the map's basemap selection. */
(() => {
  'use strict';
  const key='map2-interface-theme-v1',values=['light','dark','system'];
  const media=window.matchMedia('(prefers-color-scheme: dark)');
  let choice='system';
  try {const saved=localStorage.getItem(key);if(values.includes(saved))choice=saved;} catch (_) {}
  function apply(){document.documentElement.dataset.map2Interface=choice==='system'?(media.matches?'dark':'light'):choice;}
  function setTheme(value){
    if(!values.includes(value))return;
    choice=value;try{localStorage.setItem(key,value);}catch(_){}
    apply();const select=document.getElementById('map2InterfaceTheme');if(select)select.value=choice;
  }
  media.addEventListener('change',()=>{if(choice==='system')apply();});
  window.addEventListener('storage',event=>{if(event.key!==key)return;choice=values.includes(event.newValue)?event.newValue:'system';apply();const select=document.getElementById('map2InterfaceTheme');if(select)select.value=choice;});
  window.Map2Interface=Object.freeze({setTheme,get choice(){return choice;}});
  apply();
})();
