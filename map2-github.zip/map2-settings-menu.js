(() => {
  'use strict';
  const id=name=>document.getElementById(name);
  const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text)el.textContent=text;if(cls)el.className=cls;return el;};
  function init() {
    const list=id('b6setList');
    if (!list||!window.Map2TargetForms)throw Error('Settings dependencies unavailable');
    if(list.dataset.simpleSettings)return;
    list.dataset.simpleSettings='2';
    const forms=window.Map2TargetForms,state=window._rls2Settings;
    function section(title,key){const el=node('section',null,'m2-settings-section');const h=node('h2',title);h.id=key;el.setAttribute('aria-labelledby',key);const content=node('div',null,'m2-settings-content');el.append(h,content);list.append(el);return content;}
    const targets=section('Налаштування цілей','map2TargetSettingsTitle');
    const map=section('Налаштування карти','map2MapSettingsTitle');
    const header=id('b6setOverlay').querySelector('.b6-header');
    header.textContent='Налаштування';
    header.append(node('p','Зміни застосовуються одразу','m2-settings-subtitle'));
    const appearance=node('div',null,'m2-appearance');
    select(appearance,'Тема інтерфейсу','map2InterfaceTheme',[
      ['light','Світла'],['dark','Темна'],['system','Як у системі']
    ],window.Map2Interface?.choice||'system',value=>window.Map2Interface?.setTheme(value));
    const navigation=node('nav',null,'m2-settings-nav');navigation.setAttribute('aria-label','Розділи налаштувань');
    const sections=[targets.parentElement,map.parentElement];
    const buttons=sections.map((section,index)=>{
      const button=node('button',index===0?'Цілі':'Карта');button.type='button';button.id='map2SettingsTab-'+index;
      section.id='map2SettingsSection-'+index;button.setAttribute('aria-controls',section.id);
      button.addEventListener('click',()=>activate(index));navigation.append(button);return button;
    });
    function activate(selected){sections.forEach((section,index)=>{section.hidden=index!==selected;buttons[index].setAttribute('aria-pressed',String(index===selected));});list.scrollTop=0;}
    activate(0);header.after(appearance,navigation);
    function subheading(parent,title){parent.append(node('h3',title,'m2-settings-subheading'));}
    subheading(targets,'Відображення');

    function saveDisplay(){try{const prefs=JSON.parse(localStorage.getItem('map2-game-ui-v1')||'{}');prefs.display={...(prefs.display||{}),...state};localStorage.setItem('map2-game-ui-v1',JSON.stringify(prefs));}catch(_){}window.dispatchEvent(new Event('map2-display-change'));}
    function toggle(parent,title,key,value,change){const row=node('label',null,'m2-settings-toggle');const input=node('input');input.type='checkbox';input.id=key;input.checked=!!value;input.setAttribute('aria-label',title);row.append(node('span',title),input);parent.append(row);input.addEventListener('change',()=>change(input.checked));return input;}
    function select(parent,title,key,options,value,change){const row=node('label',null,'m2-settings-select');const input=node('select');input.id=key;for(const [v,t] of options)input.append(new Option(t,v));input.value=value;row.append(node('span',title),input);parent.append(row);input.addEventListener('change',()=>change(input.value));return input;}
    const live=id('map2LiveEnabled');
    if(live){try{live.checked=localStorage.getItem('map2-show-live-targets')!=='false';}catch(_){}toggle(targets,'Показувати цілі','map2ShowTargets',live.checked,value=>{live.checked=value;try{localStorage.setItem('map2-show-live-targets',String(value));}catch(_){}live.dispatchEvent(new Event('change',{bubbles:true}));});}
    toggle(targets,'Показувати прогнозні цілі','map2ShowPredicted',forms.config.showPredicted,value=>forms.configure({showPredicted:value}));
    toggle(targets,'Лінії треків прогнозних цілей','map2ShowPredictedTracks',forms.config.showPredictedTracks,value=>forms.configure({showPredictedTracks:value}));
    toggle(targets,'Позначки стану цілі','map2ShowTargetState',forms.config.status,value=>forms.configure({status:value}));
    const explanation=node('details',null,'m2-settings-details m2-state-explanation');explanation.append(node('summary','Що означають ОП, ПР, ІМ і ЗП'));targets.append(explanation);
    const legend=node('p','ОП — орієнтовне положення; ПР — прогноз джерела; ІМ — імітована ціль; ЗП — збережене положення.','m2-settings-status-legend');explanation.append(legend);
    const predictionNote=node('p',null,'m2-settings-status-legend');predictionNote.append(node('strong','ПР — ціль могла зникнути з системи, але її прогнозна позначка ще залишається у джерелі.'));explanation.append(predictionNote);
    subheading(targets,'Формуляр');
    select(targets,'Формуляр цілі','map2FormMode',[['off','Вимкнено'],['short','Скорочений'],['full','Повний']],forms.config.mode,value=>forms.configure({mode:value}));
    toggle(targets,'Формуляр кольором цілі','map2FormColor',state.colorForm,value=>{state.colorForm=value;saveDisplay();});
    toggle(targets,'Розсувати формуляри','map2SpreadForms',state.spreadForms,value=>{state.spreadForms=value;saveDisplay();});
    const full=node('details',null,'m2-settings-details');full.append(node('summary','Параметри повного формуляра'));const fullContent=node('div',null,'m2-settings-content');full.append(fullContent);targets.append(full);
    for(const [key,title] of [['type','Тип цілі'],['number','Номер цілі, якщо наданий'],['speed','Поточна швидкість'],['average','Середня швидкість за час спостереження'],['heading','Курс у градусах'],['altitude','Висота, якщо надана']])toggle(fullContent,title,'map2Form-'+key,forms.config[key],value=>forms.configure({[key]:value}));
    select(fullContent,'Одиниці швидкості','map2FormUnit',[['kmh','км/год'],['ms','м/с']],forms.config.unit,value=>forms.configure({unit:value}));
    function range(title,key,min,max){const row=node('label',null,'m2-settings-range');const header=node('span');const output=node('output');const input=node('input');input.type='range';input.id='map2Setting-'+key;input.min=min;input.max=max;input.step=1;input.value=state[key];input.setAttribute('aria-label',title);const sync=()=>output.textContent=input.value+(key==='trackLen'&&Number(input.value)===0?' · вимкнено':'');header.append(node('span',title),output);row.append(header,input);targets.append(row);sync();input.addEventListener('input',()=>{state[key]=Number(input.value);sync();saveDisplay();});}
    subheading(targets,'Розміри й трек');
    range('Розмір цілей','targetSize',1,5);range('Розмір формуляра','fontSize',7,20);range('Довжина треку','trackLen',0,200);
    select(targets,'Згасання після зникнення','map2TrailFade',[
      ['0','Прибирати одразу'],['5','5 секунд'],['10','10 секунд'],['15','15 секунд'],['30','30 секунд'],['60','1 хвилина'],['120','2 хвилини']
    ],String(forms.config.trailFadeSeconds),value=>forms.configure({trailFadeSeconds:Number(value)}));
    targets.append(node('p','ПР залишається на карті, доки її передає джерело. Якщо джерело задає час згасання, використовуємо його. Цей параметр керує спільним згасанням цілі, формуляра й треку після їх зникнення з джерела.','m2-settings-description'));
    map.append(node('p','Вибери підкладку для карти. Колір меню змінюється окремо — зверху.','m2-settings-description'));
    let current='normal';
    try{const saved=localStorage.getItem('map2-theme-selection-v1');if(['normal','dark','topo','sat'].includes(saved))current=saved;else if(saved==='sat-bw')current='sat';}catch(_){}
    window.map2ThemeChoice=current;
    select(map,'Тема карти','map2MapTheme',[['normal','Звичайна'],['dark','Темна'],['topo','Топографічна'],['sat','Супутникова']],current,theme=>{
      window.map2ThemeChoice=theme;try{localStorage.setItem('map2-theme-selection-v1',theme);}catch(_){}
      window.__setMap2MapType(theme);
    });
    window.__setMap2MapType(current);
    toggle(map,'Зони повітряної тривоги','map2ShowAlertZones',window.Map2Alerts.enabled,value=>window.Map2Alerts.configure(value));
    const alertLegend=node('div',null,'m2-alert-legend');
    for(const [level,title]of [['red','Червоний рівень'],['yellow','Жовтий рівень']]){const item=node('span',title);item.prepend(node('i',null,'m2-alert-dot '+level));alertLegend.append(item);}
    map.append(alertLegend);
    const alertStatus=node('p',window.Map2Alerts.status,'m2-settings-description');alertStatus.id='map2AlertsStatus';alertStatus.setAttribute('role','status');map.append(alertStatus);
    window.addEventListener('map2-alerts-change',()=>{alertStatus.textContent=window.Map2Alerts.status;id('map2ShowAlertZones').checked=window.Map2Alerts.enabled;});

    id('b6setVersion').hidden=true;
    window.dispatchEvent(new Event('map2-display-change'));window.Map2SettingsMenu=Object.freeze({ready:true});
  }
  init();
})();
