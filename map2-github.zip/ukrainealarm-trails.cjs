'use strict';
// Shared observed history. Predictions never become observed positions.
function createTrailTracker({maxPoints=200,maxTracks=1000,retentionMs=120000,now=Date.now,storagePath=null,saveIntervalMs=5000,onError=error=>console.warn("Track storage:",error.message)}={}) {
  const tracks=new Map();
  const fs=require('node:fs'),path=require('node:path');
  let dirty=false,writing=Promise.resolve();
  if(storagePath){
    try{
      if(fs.statSync(storagePath).size>32*1024*1024)throw Error('Track file too large');
      const stored=JSON.parse(fs.readFileSync(storagePath,'utf8'));
      if(stored.version!==1||!Array.isArray(stored.tracks))throw Error('Invalid track file');
      const valid=stored.tracks.filter(r=>r&&(typeof r.id==='string'||typeof r.id==='number')
        &&String(r.id).length<=256&&Number.isFinite(r.updatedAt)&&Number.isFinite(r.lastSeen)
        &&r.lastSeen<=now()+60000&&now()-r.lastSeen<=retentionMs&&Array.isArray(r.points))
        .sort((a,b)=>a.lastSeen-b.lastSeen).slice(-maxTracks);
      for(const r of valid){const points=r.points.filter(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)).slice(-maxPoints);
        if(points.length)tracks.set(r.id,{points,updatedAt:r.updatedAt,lastSeen:r.lastSeen});}
    }catch(error){if(error.code!=='ENOENT')onError(error);}
  }
  function checkpoint(){
    if(!storagePath)return Promise.resolve();
    writing=writing.then(async()=>{
      if(!dirty)return;
      dirty=false;
      const data=JSON.stringify({version:1,tracks:[...tracks].map(([id,r])=>({id,...r}))});
      try{
        await fs.promises.mkdir(path.dirname(storagePath),{recursive:true,mode:0o700});
        await fs.promises.writeFile(storagePath+'.tmp',data,{mode:0o600});
        await fs.promises.rename(storagePath+'.tmp',storagePath);
      }catch(error){dirty=true;onError(error);}
    });
    return writing;
  }
  const timer=storagePath?setInterval(()=>{void checkpoint();},saveIntervalMs):null;
  timer?.unref();
  async function close(){clearInterval(timer);await writing;await checkpoint();}

  function update(state){
    dirty=true;
    const received=now(),time=Number(state.updatedAt),serverTime=Number(state.serverTime);
    for(const [id,rec] of tracks)if(received-rec.lastSeen>retentionMs)tracks.delete(id);
    if(state.publicTargetsEnabled===false){tracks.clear();return state.targets.map(t=>({...t,observedTrack:[]}));}
    const fresh=Number.isFinite(time)&&time>0&&Number.isFinite(serverTime)&&serverTime>=time
      &&serverTime-time<Math.min(60000,Math.max(1000,(Number(state.snapshotTtl)||30)*1000));
    return state.targets.map(target=>{
      const id=target.trackId,valid=id!=null&&[target.x,target.y].every(Number.isFinite);
      let rec=valid?tracks.get(id):null;
      if(fresh&&valid){
        if(!rec){rec={points:[],updatedAt:0,lastSeen:received};tracks.set(id,rec);}
        rec.lastSeen=received;tracks.delete(id);tracks.set(id,rec);
        if(!target.prediction&&target.isFading!==true&&time>=rec.updatedAt){
          const point=[target.x,target.y],last=rec.points.at(-1);
          if(time===rec.updatedAt&&last)rec.points[rec.points.length-1]=point;
          else if(!last||last[0]!==point[0]||last[1]!==point[1])rec.points.push(point);
          rec.updatedAt=time;
          if(rec.points.length>maxPoints)rec.points=rec.points.slice(-maxPoints);
        }
      }
      while(tracks.size>maxTracks)tracks.delete(tracks.keys().next().value);
      return {...target,observedTrack:rec?rec.points.map(p=>[...p]):[]};
    });
  }
  return {update,checkpoint,close};
}
module.exports={createTrailTracker};
