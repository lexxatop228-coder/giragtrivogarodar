// Vector target rendering with type colors and a thin black contour.
(() => {
  'use strict';
  const templates = window.map2TargetSvg;
  const codes = {"1":"ic_plane","2":"ic_plane","3":"ic_missile","4":"ic_plane","5":"ic_plane","6":"ic_plane","7":"ic_plane","8":"ic_plane","9":"ic_plane","10":"ic_plane","11":"ic_drone","100":"ic_ballistic_lcr","101":"ic_ballistic_mrr","102":"ic_ballistic_srr","103":"ic_missile_sr_tasm","104":"ic_missile_arm","105":"ic_missile_sscm","106":"ic_fixed_wing_lr_tasm","107":"ic_fixed_wing_lacm","108":"ic_fixed_wing_small","109":"ic_fixed_wing_medium","110":"ic_fixed_wing_large","111":"ic_fixed_wing_airliner","112":"ic_fixed_wing_turboprop","113":"ic_fixed_wing_loitering","114":"ic_fixed_wing_very_small","115":"ic_helicopter","116":"ic_asterix_plane_stroke","200":"ic_plane","201":"ic_ground_simple","202":"ic_ground_speedy","203":"ic_ground_small","204":"ic_ground_small","205":"ic_ground_small","210":"ic_ground_fixed","211":"ic_ground_fixed_simple","212":"ic_ground_fixed_speedy","213":"ic_ground_fixed_small","214":"ic_ground_fixed_small","215":"ic_ground_fixed_small","220":"ic_ground_fixed_warning_c_small","221":"ic_ground_fixed_warning_c","222":"ic_ground_fixed_warning_c","223":"ic_ground_fixed_warning_c_small","224":"ic_ground_fixed_warning_c_small","225":"ic_ground_fixed_warning_c_small","230":"ic_ground_fixed_warning_t_small","231":"ic_ground_fixed_warning_t","232":"ic_ground_fixed_warning_t","233":"ic_ground_fixed_warning_t_small","234":"ic_ground_fixed_warning_t_small","235":"ic_ground_fixed_warning_t_small","240":"ic_ground_emitter","251":"ic_asterix_plane_masked","252":"ic_asterix_plane_stroke","253":"ic_plane_predicted","254":"ic_plane","255":"ic_plane"};
  const normalized = value => String(value || '').toLowerCase().replace(/[^a-zа-яіїєґ0-9]/g, '');
  const aliases = {su35s:'ic_su_35',su35c:'ic_su_35',su34m:'ic_su_34',su27sm3:'ic_su_27',orlan10:'ic_orlan',kab:'ic_airbomb',supercum:'ic_supercam',airbaloon:'ic_air_baloon',airballoon:'ic_air_baloon',unknown:'ic_plane',unknownaircraft:'ic_plane',невизначенаціль:'ic_plane',нц:'ic_plane',пк:'ic_air_baloon',повітрянакуля:'ic_air_baloon',бандероль:'ic_banderol',бндр:'ic_banderol',балістичнаракета:'ic_ballistic',бр:'ic_ballistic',decoy:'ic_plane',хц:'ic_plane',хибнаціль:'ic_plane',гел:'ic_helicopter',гелікоптер:'ic_helicopter'};
  const detected = new Map(Object.keys(templates).map(name => [normalized(name.slice(3)), name]));
  for (const [model, name] of Object.entries(aliases)) detected.set(model, name);
  const cache = new Map();
  const iconName = value => String(value || '').split(/[?#]/)[0].split('/').pop().replace(/\.svg$/i, '').toLowerCase();
  window.map2TargetIcon = target => {
    const model = detected.get(normalized(target.detectedType));
    let name = model || iconName(target.iconName);
    if(name==='ic_decoy'||name==='ic_air_threat_combined_white')name='ic_plane';
    if (name === 'ic_su_35c' || name === 'ic_su_35s') name = 'ic_su_35';
    if (!templates[name]) name = codes[target.type] || 'ic_plane';
    // Preserve the original Map 2 Shahed image for all four variants.
    if (['ic_shahed','ic_shahed_mesh','ic_shahed_jet','ic_shahed_jet_mesh'].includes(name)) return 'assets/shahedv.png';
    const color = window.Map2Symbols.colorFor(target);
    const key = name + color;
    if (!cache.has(key)) cache.set(key, 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(templates[name].replaceAll('__COLOR__', color)));
    return cache.get(key);
  };
})();
