/* Air-alert polygons from the same public source as the targets. */
(() => {
  'use strict';
  const key='map2-alert-zones-v1',map=window.map2Base.map;
  let enabled=true;try{enabled=localStorage.getItem(key)!=='false';}catch(_){}
  const pane=map.createPane('air-alert-zones');pane.style.zIndex='350';pane.style.pointerEvents='none';
  const renderer=L.canvas({pane:'air-alert-zones',padding:.15});
  let geometry,geometryLoading,inFlight,timer,stopped=false,lastData,renderKey='',layer;
  let oldServer=false;
  let status='Очікуємо дані тривог…';
  function notify(){window.dispatchEvent(new CustomEvent('map2-alerts-change',{detail:{enabled,status}}));}
  function setStatus(value){status=value;notify();}
  async function loadGeometry(){
    if(geometry)return geometry;
    if(!geometryLoading)geometryLoading=(async()=>{
      const response=await fetch('assets/alert-regions.geojson',{cache:'force-cache',signal:AbortSignal.timeout(20000)});
      if(!response.ok)throw Error('Geometry unavailable');const data=await response.json();
      if(data.type!=='FeatureCollection'||!Array.isArray(data.features))throw Error('Invalid geometry');
      geometry=data.features.filter(f=>['Polygon','MultiPolygon'].includes(f.geometry?.type)&&f.properties?.regionId!=null);
      renderKey='';return geometry;
    })().finally(()=>geometryLoading=null);
    return geometryLoading;
  }
  function render(){
    if(!enabled){if(layer)map.removeLayer(layer);layer=null;renderKey='';return;}
    if(!geometry||!lastData?.available)return;
    const nextKey=lastData.actionIndex+'|'+lastData.stale;
    if(nextKey===renderKey)return;
    const regions=new Map(lastData.regions.map(r=>[String(r.id),r]));
    const features=geometry.filter(f=>regions.has(String(f.properties.regionId)))
      .sort((a,b)=>{const ar=regions.get(String(a.properties.regionId)),br=regions.get(String(b.properties.regionId));return Number(ar.level==='red')-Number(br.level==='red')||(a.properties.rank||0)-(b.properties.rank||0);});
    const next=L.geoJSON({type:'FeatureCollection',features},{pane:'air-alert-zones',renderer,interactive:false,
      style:feature=>{const region=regions.get(String(feature.properties.regionId));return {color:region.level==='red'?'#e34b51':'#e8b512',weight:1,opacity:lastData.stale ? 0.3 : 0.65,fillColor:region.level==='red'?'#ed3b49':'#ffc200',fillOpacity:lastData.stale ? 0.07 : 0.22,dashArray:lastData.stale?'4 5':null};}
    }).addTo(map);
    if(layer)map.removeLayer(layer);layer=next;renderKey=nextKey;
    const matched=new Set(features.map(f=>String(f.properties.regionId))).size;
    if(matched<regions.size)setStatus(status+' · без меж: '+(regions.size-matched));
  }
  function configure(value){enabled=!!value;try{localStorage.setItem(key,String(enabled));}catch(_){}render();notify();if(enabled)void refresh();}
  function refresh(){
    if(window.Map2Config.staticHosting){setStatus('GitHub Pages: дані тривог потребують окремого сервера.');return Promise.resolve();}
    if(inFlight)return inFlight;
    inFlight=(async()=>{
      try{
        const response=await fetch('/api/alerts',{cache:'no-store',signal:AbortSignal.timeout(12000)});
        oldServer=response.status===404;
        if(!response.ok)throw Error('Alert source unavailable');const data=await response.json();
        if(typeof data.available!=='boolean'||!Array.isArray(data.regions))throw Error('Invalid alerts');
        if(data.available){
          const regions=data.regions.filter(r=>r&&typeof r.id==='string'&&['red','yellow'].includes(r.level));
          lastData={...data,regions};
          setStatus(data.stale?'Тривоги: застарілі дані':regions.length?'Зон тривоги: '+regions.length:'Повітряних тривог немає');
          if(enabled){await loadGeometry();render();}
        }else setStatus('Очікуємо дані тривог…');
      }catch{
        if(lastData){lastData={...lastData,stale:true};render();}
        setStatus(oldServer?'Відкрито стару версію сервера. Запустіть start-map.cmd.':'Тривоги: немає свіжих даних');
      }
    })().finally(()=>inFlight=null);return inFlight;
  }
  async function poll(){await refresh();if(!stopped)timer=setTimeout(poll,5000);}
  window.Map2Alerts=Object.freeze({configure,refresh,get enabled(){return enabled;},get status(){return status;},get layer(){return layer;}});
  window.addEventListener('pagehide',()=>{stopped=true;clearTimeout(timer);});
  if(window.Map2Config.staticHosting)void refresh();else void poll();
})();
