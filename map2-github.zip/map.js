/* Map layers; the interface theme is configured separately. */
(() => {
  'use strict';
  const map=L.map('patMapFullLeaflet2',{center:[49,31],zoom:6,zoomControl:false,attributionControl:true});
  L.control.scale({position:'topleft',maxWidth:180,metric:true,imperial:false}).addTo(map);
  const osm=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{subdomains:'abc',maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(map);
  const terrain=L.tileLayer('https://{s}.google.com/vt/lyrs=p&x={x}&y={y}&z={z}',{subdomains:['mt0','mt1','mt2','mt3'],maxZoom:20,attribution:'&copy; Google'});
  const sat=L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{subdomains:['mt0','mt1','mt2','mt3'],maxZoom:20,attribution:'&copy; Google'});
  const darkPane=map.createPane('map2-dark-tiles');darkPane.style.filter='grayscale(1) invert(1) brightness(.72)';
  const dark=window.Map2Config.jawgAccessToken?L.maplibreGL({style:window.map2ArchiveDarkStyle,interactive:false,preserveDrawingBuffer:true,attribution:'&copy; <a href="https://www.jawg.io/">Jawg Maps</a> | &copy; OpenStreetMap contributors'}):L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{pane:'map2-dark-tiles',subdomains:'abc',maxZoom:19,attribution:'&copy; OpenStreetMap contributors'});
  const layers={osm,terrain,sat,dark};window.__map2BaseLayers=layers;
  window.__setMap2MapType=type=>{
    const target=layers[{normal:'osm',topo:'terrain',sat:'sat',dark:'dark'}[type]]||osm;
    for(const layer of Object.values(layers))if(layer!==target&&map.hasLayer(layer))map.removeLayer(layer);
    if(!map.hasLayer(target))target.addTo(map);target.bringToBack?.();
    const isDark=type==='dark'||type==='sat';document.getElementById('patMapFullWin2').style.setProperty('--ua-form-default',isDark?'#f5f7fb':'#101010');map.getContainer().style.backgroundColor=isDark?'#191919':'#f2ede3';
  };
  window.map2Base=Object.freeze({map,targets:L.layerGroup().addTo(map)});
})();
