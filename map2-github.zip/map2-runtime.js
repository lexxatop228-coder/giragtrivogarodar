/* Shared display preferences, settings panel and accessible help dialogs. */
(() => {
  'use strict';
  const byId=id=>document.getElementById(id),storageKey='map2-game-ui-v1';
  const display={colorForm:false,targetSize:3,fontSize:12,trackLen:33,spreadForms:false};
  try{
    const saved=JSON.parse(localStorage.getItem(storageKey)||'{}').display||{};
    for(const key of ['colorForm','spreadForms'])if(typeof saved[key]==='boolean')display[key]=saved[key];
    for(const [key,min,max] of [['targetSize',1,5],['fontSize',7,20],['trackLen',0,200]])
      if(Number.isFinite(saved[key]))display[key]=Math.max(min,Math.min(max,Math.round(saved[key])));
  }catch(_){}
  window._rls2Settings=display;
  window.MAP2_TARGET_SIZE_SCALES=Object.freeze({1:.65,2:.82,3:1,4:1.2,5:1.4});
  byId('map2LiveEnabled').addEventListener('change',()=>window.dispatchEvent(new Event('map2-display-change')));
  window._b6setBadge=value=>{byId('patMap2Btn6Badge').textContent=value;};
  const panel=byId('b6setOverlay'),openButton=byId('patMap2Btn6');
  function focusable(root){return [...root.querySelectorAll('button,input,select,textarea,summary,a[href],[tabindex="0"]')].filter(el=>!el.disabled&&el.getClientRects().length);}
  function trap(event,root){
    if(event.key!=='Tab')return;const nodes=focusable(root);if(!nodes.length)return;
    const first=nodes[0],last=nodes.at(-1);
    if(event.shiftKey&&(document.activeElement===first||!root.contains(document.activeElement))){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&(document.activeElement===last||!root.contains(document.activeElement))){event.preventDefault();first.focus();}
  }
  function closeSettings(){panel.classList.remove('b6-open');panel.inert=true;panel.setAttribute('aria-hidden','true');openButton.setAttribute('aria-expanded','false');openButton.focus();}
  openButton.addEventListener('click',()=>{
    if(panel.classList.contains('b6-open'))return closeSettings();
    panel.inert=false;panel.setAttribute('aria-hidden','false');panel.classList.add('b6-open');openButton.setAttribute('aria-expanded','true');focusable(panel)[0]?.focus();
  });
  byId('b6setCloseBtn').addEventListener('click',closeSettings);
  document.addEventListener('pointerdown',event=>{if(panel.classList.contains('b6-open')&&!panel.contains(event.target)&&!openButton.contains(event.target)&&!document.querySelector('.m2-dialog-overlay'))closeSettings();});
  document.addEventListener('keydown',event=>{
    if(document.querySelector('.m2-dialog-overlay')||!panel.classList.contains('b6-open'))return;
    if(event.key==='Escape')closeSettings();else trap(event,panel);
  });
  function el(tag,text,cls){const node=document.createElement(tag);if(text!=null)node.textContent=text;if(cls)node.className=cls;return node;}
  function button(text,run){const node=el('button',text,'m2-button');node.type='button';node.addEventListener('click',run);return node;}
  let closeDialog;
  function modal(title,build){
    closeDialog?.();const previous=document.activeElement,overlay=el('div',null,'m2-dialog-overlay'),dialog=el('section',null,'m2-dialog');
    const heading=el('h3',title);heading.id='m2DialogHeading';dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-labelledby',heading.id);dialog.tabIndex=-1;
    dialog.append(heading);overlay.append(dialog);byId('patMapFullWin2').append(overlay);
    // Keep keyboard and assistive technology inside the active dialog.
    const siblings=[...byId('patMapFullWin2').children].filter(n=>n!==overlay).map(node=>({node,inert:node.inert}));siblings.forEach(({node})=>node.inert=true);
    function close(){overlay.remove();document.removeEventListener('keydown',onKey,true);siblings.forEach(({node,inert})=>node.inert=inert);previous?.isConnected&&previous.focus();closeDialog=null;}
    function onKey(event){if(event.key==='Escape'){event.stopImmediatePropagation();close();}else trap(event,dialog);}
    document.addEventListener('keydown',onKey,true);overlay.addEventListener('click',event=>{if(event.target===overlay)close();});
    build(dialog,close);const actions=el('div',null,'m2-actions');actions.append(button('Закрити',close));dialog.append(actions);closeDialog=close;(focusable(dialog)[0]||dialog).focus();
  }
  window.Map2UI=Object.freeze({helpers:Object.freeze({button,modal})});
  window.map2Base.map.on('moveend zoomend resize',()=>window.dispatchEvent(new Event('map2-layout-change')));
})();
