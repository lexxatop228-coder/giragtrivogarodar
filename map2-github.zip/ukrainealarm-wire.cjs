(function (root) {
    "use strict";
    function unwrap(packet) {
        // Centrifuge v2 can pass a publication as {data: {data: snapshot,
        // offset}}; history can pass the inner publication or snapshot itself.
        // Stop at a recognized snapshot, not at arbitrary transport metadata.
        for (let depth = 0; depth < 4 && packet && typeof packet === "object"; depth++) {
            if (packet.v !== undefined || Array.isArray(packet.targets)) return packet;
            if (!packet.data || typeof packet.data !== "object") break;
            packet = packet.data;
        }
        return packet;
    }
    // v2 tuple codec; only the transport changes, not renderer/API models.
    function decode(packet) {
        packet = unwrap(packet);
        if (!packet) return packet;
        if (packet.v === undefined) {
            if (!Array.isArray(packet.targets)) throw new Error("Invalid target snapshot");
            return packet;
        }
        if (packet.v !== 2 || !Array.isArray(packet.d) || packet.d.length !== 12)
            throw new Error("Unsupported target snapshot format");
        const [time, updated, extrapUpdated, fog, ttl, cells, styles, ids, targets, trail, extrapolation, movement] = packet.d;
        const timestamp = value => value == null ? 0 : time + value;
        function cell(index) {
            const value = cells[index];
            if (!Array.isArray(value) || value.length < 4) throw new Error("Invalid target cell reference");
            return {x: value[0], y: value[1], cellWidth: value[2], cellHeight: value[3], gridLevel: value[4] || ""};
        }
        function trackId(value) {
            if (typeof value !== "string") throw new Error("Invalid track ID reference");
            if (value.startsWith("~~")) return value.slice(1);
            if (!value.startsWith("~")) return value;
            const bytes = Array.from(atob(value.slice(1).replace(/-/g, "+").replace(/_/g, "/") + "=="),
                char => char.charCodeAt(0).toString(16).padStart(2, "0"));
            // Guid.ToByteArray uses little endian for its first three fields.
            return [3, 2, 1, 0, 5, 4, 7, 6, 8, 9, 10, 11, 12, 13, 14, 15].map(index => bytes[index]).join("");
        }
        const decodedIds = ids.map(trackId);
        function target(row) {
            const [id, geometry, styleIndex, heading, count, hits, duration, offsetX, offsetY, fading, fadeStart, fadeEnd, prediction] = row;
            const style = styles[styleIndex];
            if (!style || decodedIds[id] === undefined) throw new Error("Invalid target style/ID reference");
            return {...cell(geometry), trackId: decodedIds[id], type: style[0], formular: style[1],
                detectedType: style[2], iconName: style[3], iconScale: style[4], heading: heading ?? null,
                currentCount: count ?? 0, h: hits ?? 0, movementDurationMs: duration ?? 0,
                ...(offsetX ? {markerOffsetX: offsetX} : {}), ...(offsetY ? {markerOffsetY: offsetY} : {}),
                ...(fading ? {isFading: true} : {}),
                ...(fadeStart != null ? {fadeStartedAt: timestamp(fadeStart)} : {}),
                ...(fadeEnd != null ? {fadeEndsAt: timestamp(fadeEnd)} : {}),
                ...(prediction ? {prediction: {fromX: prediction[0], fromY: prediction[1], toX: prediction[2],
                    toY: prediction[3], startedAt: timestamp(prediction[4]), endsAt: timestamp(prediction[5])}} : {})};
        }
        function sample(row) {
            const [age, strength, minimum, retention, delay, duration, appearDelay, appearDuration, visibleUntil] = row;
            return {age: age ?? 0, baseStrength: strength ?? null, minimumStrength: minimum ?? 0,
                retentionAge: retention ?? null,
                ...(delay != null ? {fadeDelay: delay} : {}), ...(duration != null ? {fadeDuration: duration} : {}),
                ...(appearDelay != null ? {appearDelay} : {}), ...(appearDuration != null ? {appearDuration} : {}),
                ...(visibleUntil != null ? {visibleUntil} : {})};
        }
        function heat(row) {
            const [geometry, age, hits, strength, minimum, retention, samples, anchors, predicted] = row;
            return {...cell(geometry), age: age ?? 0, h: hits ?? 0,
                ...(strength != null ? {baseStrength: strength} : {}), ...(minimum ? {minimumStrength: minimum} : {}),
                ...(retention != null ? {retentionAge: retention} : {}),
                ...(samples != null ? {samples: samples.map(sample)} : {}),
                ...(anchors != null ? {extrapolationHoldAnchors: anchors.map(index => {
                    const {gridLevel, ...geometry} = cell(index); return geometry;
                })} : {}), ...(predicted ? {predictedExtrapolation: true} : {})};
        }
        return {...(packet.p === 0 ? {publicTargetsEnabled: false} : {}),
            targets: targets.map(target), trail: trail.map(heat), extrapolationTrail: extrapolation.map(heat),
            serverTime: time, updatedAt: timestamp(updated), extrapolationUpdatedAt: timestamp(extrapUpdated),
            fog, snapshotTtl: ttl, movement: movement == null ? null : {from: movement[0].map(target),
                fromUpdatedAt: timestamp(movement[1]), startedAt: timestamp(movement[2])}};
    }
    function createReader() {
        let epoch = null, revision = "0", serverTime = 0;
        const seenEpochs = new Set();
        return packet => {
            packet = unwrap(packet);
            const state = decode(packet);
            if (packet?.v === 2) {
                const next = String(packet.q);
                if (!/^\d+$/.test(next) || typeof packet.e !== "string") throw new Error("Invalid snapshot revision");
                if (epoch === packet.e) {
                    if (next.length < revision.length || (next.length === revision.length && next <= revision)) return null;
                } else if (seenEpochs.has(packet.e) || state.serverTime < serverTime) return null;
                if (epoch !== packet.e) {
                    seenEpochs.add(packet.e);
                    // Bound memory even across an unusually long-lived WebView.
                    if (seenEpochs.size > 8) seenEpochs.delete(seenEpochs.values().next().value);
                }
                epoch = packet.e; revision = next; serverTime = state.serverTime;
            }
            return state;
        };
    }
    root.detailTargetWire = {decode, createReader};
})(typeof window !== "undefined" ? window : globalThis);
/* Cache refresh.       */
