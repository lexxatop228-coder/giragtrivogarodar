/* Compact target formulars and an average over observed positions this session. */
(() => {
  'use strict';
  const key = 'map2-target-form-v1';
  const defaults = {mode:'short',type:true,number:false,speed:true,average:false,heading:true,altitude:false,unit:'kmh',status:true,showPredicted:true,showPredictedTracks:true,trailFadeSeconds:15};
  const config = {...defaults};
  function apply(values) {
    if (!values || typeof values !== 'object') return;
    if (Number.isFinite(values.trailFadeSeconds)) config.trailFadeSeconds=Math.max(0,Math.min(120,Math.round(values.trailFadeSeconds)));
    if (['off','short','full'].includes(values.mode)) config.mode=values.mode;
    if (['kmh','ms'].includes(values.unit)) config.unit=values.unit;
    for (const name of ['type','number','speed','average','heading','altitude','status','showPredicted','showPredictedTracks']) if (typeof values[name]==='boolean') config[name]=values[name];
  }
  try { apply(JSON.parse(localStorage.getItem(key)||'{}')); } catch (_) {}
  const history = new Map();
  const normalize = value => String(value||'').toLowerCase().replace(/[^a-zа-яіїєґ0-9]/g,'');
  function describe(target) {
    // Keep concrete source model names ahead of broad icon/numeric categories.
    // Rows render these names with textContent, never as source-provided HTML.
    const sourceName=typeof target.detectedType==='string'
      ? target.detectedType.replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim() : '';
    const model=normalize(sourceName), icon=normalize(target.iconName);
    const named=value=>({short:value,full:value});
    const identityName=model||icon.replace(/^ic/,'').replace(/svg$/,'');
    if(/^(unknown|unknownaircraft|невизначенаціль|нц|airthreatcombinedwhite)$/.test(identityName))return {short:'НЦ',full:'Невизначена ціль'};
    if(/^(decoy|хц|хибнаціль)$/.test(identityName))return {short:'ХЦ',full:'Хибна ціль'};
    const strikeNames={уд:['УД','Ударний нереактивний дрон'],руд:['РУД','Реактивний ударний дрон'],умд:['УМД','Ударний меш-дрон'],румд:['РУМД','Реактивний ударний меш-дрон']};
    if(strikeNames[model])return {short:strikeNames[model][0],full:strikeNames[model][1]};
    if (/^(molnia|molniya|molniia|молния|молнія)(\d+)?$/.test(identityName))
      return named('Молнія'+(identityName.match(/\d+$/)?.[0]?' '+identityName.match(/\d+$/)[0]:''));
    const shahed=/^(shahed|шахед)(jet|reactive|реактивний)?(mesh|меш)?$/.test(identityName);
    if (shahed) {
      const reactive=/jet|reactive|реактивний/.test(identityName), mesh=/mesh|меш/.test(identityName);
      return mesh ? (reactive?{short:'РУМД',full:'Реактивний ударний меш-дрон'}:{short:'УМД',full:'Ударний меш-дрон'})
        : (reactive?{short:'РУД',full:'Реактивний ударний дрон'}:{short:'УД',full:'Ударний нереактивний дрон'});
    }
    const aliases={banderol:'БНДР',бандероль:'БНДР',supercam:'Supercam',supercum:'Supercam',orlan:'Орлан',орлан:'Орлан',zala:'ZALA',merlin:'Merlin',mohajer:'Mohajer'};
    if (aliases[identityName]) return {short:aliases[identityName],full:/^(banderol|бандероль)$/.test(identityName)?'Бандероль':aliases[identityName]};
    const generic=/^(unknown|unknownaircraft|undefined|null|none|невідомий|невизначенаціль|нц|drone|uav|бпла|missile|cruisemissile|ракета|крилатаракета|ballistic|ballisticmissile|балістичнаракета|airbomb|kab|каб|helicopter|rotarywing|aircraft|plane|airplane|decoy|airbaloon|airballoon|уд|руд|умд|румд|ударнийдрон|реактивнийударнийдрон|ударниймешдрон|реактивнийударниймешдрон)$/;
    if (sourceName && !generic.test(model)) {
      const aircraft=sourceName.match(/^(Su|Mig|Tu|An|F|A)[ _-]?(\d+)(.*)$/i);
      if (aircraft) {
        const names={su:'Су',mig:'МіГ',tu:'Ту',an:'Ан',f:'F',a:'А'};
        return named(names[aircraft[1].toLowerCase()]+'-'+aircraft[2]+aircraft[3]);
      }
      return named(sourceName);
    }
    const text=model+' '+icon+' '+normalize(target.formular);
    const identity=model||icon;
    const reactive=/shahedjet/.test(identity)||(!/shahed/.test(identity)&&/реакт|reactive|jet/.test(text)&&!/нереакт|nonreactive|nonjet/.test(text));
    if (/mesh|меш/.test(text)) return reactive?{short:'РУМД',full:'Реактивний ударний меш-дрон'}:{short:'УМД',full:'Ударний меш-дрон'};
    if (/banderol|бандерол/.test(text)) return {short:'БНДР',full:'Бандероль'};
    if (reactive) return {short:'РУД',full:'Реактивний ударний дрон'};
    if (/shahed|lancet|italmas|molnia|ударн/.test(text)) return {short:'УД',full:'Ударний нереактивний дрон'};
    for (const [pattern,name] of [[/supercam|supercum/,'Supercam'],[/orlan|орлан/,'Орлан'],[/zala/,'ZALA'],[/merlin/,'Merlin'],[/mohajer/,'Mohajer']]) if (pattern.test(text)) return {short:name,full:name};
    if (/ballistic|баліст/.test(text) || [100,101,102].includes(Number(target.type))) return {short:'БР',full:'Балістична ракета'};
    if (/airbomb|kab|каб/.test(text)) return {short:'КАБ',full:'Керована авіабомба'};
    if (/missile|banderol|ракета/.test(text) || [3,103,104,105,106,107].includes(Number(target.type))) return {short:'КР',full:'Крилата ракета'};
    const aircraft=String(target.detectedType||'').match(/^(Su|Mig|Tu|An|F|A)[ _-]?(\d+)/i);
    if (aircraft) {
      const names={su:'Су',mig:'МіГ',tu:'Ту',an:'Ан',f:'F',a:'А'};
      const name=names[aircraft[1].toLowerCase()]+'-'+aircraft[2];return {short:name,full:name};
    }
    if (/helicopter|rotarywing/.test(text) || Number(target.type)===115) return {short:'ГЕЛ',full:'Гелікоптер'};
    if (/drone|бпла/.test(text) || Number(target.type)===11) return {short:'БПЛА',full:'БПЛА'};
    if (/decoy/.test(text)) return {short:'ХЦ',full:'Хибна ціль'};
    if (/airbaloon/.test(text)) return {short:'ПК',full:'Повітряна куля'};
    const label=window.Map2Symbols?.get(target.type)?.label;
    if (Number(target.type)===8) return {short:'ПП',full:'Повітряний противник'};
    return {short:label||'НЦ',full:target.detectedType||label||'Невизначена ціль'};
  }
  function record(target,time,coordinate,valid,distance) {
    if (!valid || target.prediction || target.isFading || !Number.isFinite(time) || !coordinate.every(Number.isFinite)) return;
    const old=history.get(target.trackId);
    if (!old) {
      history.set(target.trackId,{lastTime:time,coordinate:[...coordinate],distanceKm:0,durationMs:0});
      while (history.size>1000) history.delete(history.keys().next().value);
      return;
    }
    if (time<=old.lastTime) return;
    const km=distance(old.coordinate,coordinate)/1000;
    if (!Number.isFinite(km) || km<0) return;
    old.distanceKm+=km;old.durationMs+=time-old.lastTime;old.lastTime=time;old.coordinate=[...coordinate];
  }
  function average(trackId) {
    const record=history.get(trackId);
    return record?.durationMs>0 ? record.distanceKm*3600000/record.durationMs : null;
  }
  function sourceSpeed(target) {
    if (!Number.isFinite(target.speed)||target.speed<0) return null;
    const unit=String(target.speedUnit||'kmh').toLowerCase();
    return /^(m\/s|ms|м\/с)$/.test(unit) ? target.speed*3.6 : target.speed;
  }
  function speedText(value) {
    if (!Number.isFinite(value)) return '—';
    const n=config.unit==='ms'?value/3.6:value;
    return String(Math.round(n));
  }
  function state(target,context={}) {
    const codes=[];
    if(Number(target.type)===254) codes.push('ІМ');
    if(target.prediction) codes.push('ПР');
    else if(context.stale || target.isFading===true) codes.push('ЗП');
    else codes.push('ОП');
    return codes.join(' · ');
  }
  function rows(target,context={}) {
    if (config.mode==='off') return [];
    const info=describe(target);
    const suffix=config.status?' · '+state(target,context):'';
    if (config.mode!=='full'&&!context.selected) return [info.short+suffix];
    const lines=[];
    if (config.type) lines.push(info.short+suffix);
    else if(config.status) lines.push(state(target,context));
    if (config.number && target.targetNumber!=null && target.targetNumber!=='') lines.push(String(target.targetNumber));
    const speeds=[];
    if (config.speed) speeds.push(speedText(context.speedKmh));
    if (config.average) speeds.push(speedText(average(target.trackId)));
    if (speeds.length) lines.push(speeds.join('\u2002'));
    if (config.altitude && Number.isFinite(target.altitude)) lines.push('H '+target.altitude+(target.altitudeUnit?' '+target.altitudeUnit:''));
    if (config.heading) lines.push(Number.isFinite(target.heading)?Math.round((target.heading%360+360)%360)+'°':'—°');
    return lines;
  }
  function configure(values) {
    apply(values);
    try {localStorage.setItem(key,JSON.stringify(config));} catch (_) {}
    window.dispatchEvent(new Event('map2-display-change'));
  }
  window.Map2TargetForms=Object.freeze({config,configure,describe,state,rows,record,average,sourceSpeed,clear:()=>history.clear()});
})();
