(() => {
  'use strict';
  if (!window.map2Base) return;
  const {map, targets} = window.map2Base;
  const banner = document.getElementById('patMap2NoSignalBanner');
  const status = document.createElement('div');
  status.id = 'ukrainealarmStatus'; status.hidden=true; status.setAttribute('role', 'status');
  document.getElementById('patMapFullContainer2').append(status);
  map.attributionControl.addAttribution('Цілі: <a href="https://map.ukrainealarm.com/" target="_blank" rel="noopener">UkraineAlarm</a>');
  let snapshot, expires = 0, snapshotStale = false;
  let delivery = {}, connectionWarning = '';
  const selected = new Set();
  const liveMarkers = new Map(), targetStates=new Map();
  let fadeFrame=null;
  function resetTargets() {
    liveMarkers.clear(); targets.clearLayers();
  }
  function placeTarget(marker, position) {
    marker.setLatLng(position);
    // Leaflet rounds normal marker updates to whole pixels; preserve the exact displayed point.
    const element = marker.getElement();
    if (element && !map._animatingZoom) {
      L.DomUtil.setPosition(element, map.project(marker.getLatLng(), map.getZoom()).subtract(map.getPixelOrigin()));
    }
  }
  function moveTarget(marker, coord) {
    const position = L.latLng(coord);
    if (marker.map2Destination?.equals(position, 0)) return;
    marker.map2Destination = position;
    // Apply the current coordinates supplied by the snapshot immediately.
    placeTarget(marker, position);
  }
  function message(text, error = false) {
    status.textContent = text;
    banner.textContent = text; banner.classList.toggle('pm2-visible', error);
    const enabled=document.getElementById('map2LiveEnabled')?.checked!==false;
    const all=enabled?(snapshot?.targets||[]).filter(t=>Number.isFinite(t.x)&&Number.isFinite(t.y)&&(snapshotStale||!targetExpired(t))):[];
    const forecasts=all.filter(t=>!!t.prediction).length;
    const hasData=enabled&&!!snapshot&&!snapshotStale;
    window._b6setBadge?.(hasData?all.length:'—');
    const forecastBadge=document.getElementById('patMap2PredictedBadge');
    if(forecastBadge) forecastBadge.textContent=hasData?forecasts:'—';
    const countButton=document.getElementById('patMap2Btn6');
    countButton.classList.toggle('map2-source-unavailable',!hasData);
    countButton.title=`Усього: ${all.length}; прогнозних: ${forecasts}; показано: ${targets.getLayers().length}`;
    countButton.setAttribute('aria-label',`Налаштування. Усього цілей ${all.length}, прогнозних ${forecasts}, показано ${targets.getLayers().length}`);
    if(!hasData){
      const reason=enabled?(connectionWarning||text):'Показ цілей вимкнено';
      countButton.title='Немає актуальних даних про цілі. '+reason;
      countButton.setAttribute('aria-label','Налаштування. Немає актуальних даних про цілі. '+reason);
    }

  }
  function clear(text) { snapshot = null; snapshotStale = false; connectionWarning = ''; resetTargets(); targetStates.clear(); cancelAnimationFrame(fadeFrame);fadeFrame=null; trails.clear(); trailLayer?.redraw(); selected.clear(); message(text, true); }
  function markSnapshotStale() {
    if (!snapshot) return;
    if (!snapshotStale) { snapshotStale = true; draw(); }
    else updateLiveStatus();
  }
  function connectionIssue(text) {
    connectionWarning = text;
    if (snapshot) {
      if (Date.now() >= expires) markSnapshotStale();
      else updateLiveStatus();
    } else message('Очікування першого оновлення…');
  }
  function targetExpired(target, now = Date.now()) {
    return (target.isFading === true || !!target.prediction)
      && Number.isFinite(target.fadeEndsAt) && target.fadeEndsAt <= now;
  }
  function currentSpeedValue(target) {
    if (snapshotStale || target.prediction || target.isFading === true) return null;
    const estimate = target.speedEstimate;
    if (!['ready', 'uncertain'].includes(estimate?.status)) return null;
    const value = estimate.valueKmh ?? target.estimatedSpeedKmh;
    return Number.isFinite(value) && value >= 0 ? value : null;
  }
  function layoutLabels() {
    const placed=[], bounds=map.getContainer().getBoundingClientRect();
    const spread=!!window._rls2Settings?.spreadForms;
    for (const marker of targets.getLayers()) {
      const parts=marker.map2Parts; if (!parts) continue;
      const {root,label,leader}=parts;
      root.classList.toggle('ua-forms-spread',spread);
      const compact=label.classList.contains('ua-form-short');
      label.style.transform=compact?'translate(4px, -50%)':'translate(4px, -4px)'; leader.hidden=true;
      if (label.hidden || !spread) continue;
      const base=label.getBoundingClientRect();
      let dx=0,dy=0,rect;
      for(let attempt=0;attempt<100;attempt++) {
        dy=attempt===0?0:(Math.ceil(attempt/2)*(base.height+6)*(attempt%2?1:-1));
        dx=Math.max(bounds.left+4-base.left,Math.min(0,bounds.right-4-base.right));
        dy=Math.max(bounds.top+4-base.top,Math.min(dy,bounds.bottom-4-base.bottom));
        rect={left:base.left+dx,right:base.right+dx,top:base.top+dy,bottom:base.bottom+dy};
        if(!placed.some(p=>rect.left<p.right+4&&rect.right+4>p.left&&rect.top<p.bottom+4&&rect.bottom+4>p.top))break;
        if(attempt>60)dx-=base.width+10;
      }
      label.style.transform=compact?`translate(${4+dx}px, calc(-50% + ${dy}px))`:`translate(${4+dx}px, ${-4+dy}px)`;
      const actual=label.getBoundingClientRect(); placed.push(actual);
      const box=root.getBoundingClientRect(),sx=box.left+marker.map2Size/2,sy=box.top+marker.map2Size/2;
      const ex=Math.max(actual.left,Math.min(sx,actual.right)),ey=Math.max(actual.top,Math.min(sy,actual.bottom));
      const x=ex-sx,y=ey-sy;
      leader.style.width=Math.hypot(x,y)+'px';
      leader.style.transform=`rotate(${Math.atan2(y,x)}rad)`;leader.hidden=false;
    }
  }
  // Same fitted Mercator projection and 260 × 175 viewBox as the source map.
  const rad = d => d * Math.PI / 180, deg = r => r * 180 / Math.PI;
  const my = lat => Math.log(Math.tan(Math.PI / 4 + rad(lat) / 2));
  const west = 22.137059, east = 40.2275801, north = 52.3791473, south = 44.184598;
  const scale = Math.min(260 / rad(east-west), 175 / (my(north)-my(south)));
  const ox = (260-rad(east-west)*scale)/2, oy = (175-(my(north)-my(south))*scale)/2;
  function position(t) {
    return [deg(2*Math.atan(Math.exp(my(north)-(Number(t.y)*175-oy)/scale))-Math.PI/2), west+deg((Number(t.x)*260-ox)/scale)];
  }

  // ---- Треки цілей (як на Карті 2 у app.html) ----
  // Лінія + квадратики-відмітки; довжина = «Довжина треку цілі» (0..200 відміток).
  // Історія надходить із локального сервера; прогноз не додається до пройденого шляху.
  const TRAIL_COLOR = '#D90047', TRAIL_TICK_PX = 3, TRAIL_LINE_PX = 1;
  const trails = new Map(); // trackId -> {pts:[[lat,lng],...]}
  const trailLimit = () => { const v = window._rls2Settings?.trackLen; return Number.isFinite(v) ? v : 33; };
  const trailFadeDuration=()=>window.Map2TargetForms.config.trailFadeSeconds*1000;
  function fadeOpacity(startedAt,now=Date.now(),duration=trailFadeDuration()) {
    if(startedAt==null)return 1;
    return duration>0?Math.max(0,Math.min(1,1-(now-startedAt)/duration)):0;
  }
  function syncTrailPresence() {
    const now=Date.now(),present=new Set();
    for(const target of snapshot?.targets||[]){
      if(!Number.isFinite(target.x)||!Number.isFinite(target.y)||(!snapshotStale&&targetExpired(target)))continue;
      const id=target.trackId;present.add(id);
      let state=targetStates.get(id);
      if(!state){state={target,startedAt:null,present:true};targetStates.set(id,state);}
      state.target=target;state.present=true;
      const sourceStart=Number(target.fadeStartedAt),sourceEnd=Number(target.fadeEndsAt);
      const hasSourceFade=(target.isFading===true||!!target.prediction)
        &&sourceStart>0&&sourceEnd>sourceStart;
      if(hasSourceFade){
        // A forecast can fly normally before a FUTURE source fade starts.
        // Keep the source duration, rather than applying our post-removal timer.
        const sourceNow=Number(snapshot.serverTime)+Math.max(0,now-Number(delivery.receivedAt||now));
        state.startedAt=now+sourceStart-sourceNow;
        state.duration=sourceEnd-sourceStart;state.fadeMode='source';
      }else if(target.isFading===true){
        if(state.fadeMode!=='local'){state.startedAt=now;state.fadeMode='local';state.duration=null;}
      }else {
        // Prediction is a source state, not a signal to discard a visible target.
        state.startedAt=null;state.duration=null;state.fadeMode=null;
      }
    }
    for(const [id,state] of targetStates){
      if(!present.has(id)){
        state.present=false;
        if(state.startedAt==null||state.startedAt>now){state.startedAt=now;state.fadeMode='local';state.duration=null;}
      }
    }
    for(const [id,rec] of trails){
      const state=targetStates.get(id);
      rec.disappearedAt=state?state.startedAt:(rec.disappearedAt??now);
      rec.fadeDuration=state?.fadeMode==='source'?state.duration:null;
    }
  }
  function animateFades() {
    fadeFrame=null;const now=Date.now();let pending=false,removed=false;
    for(const [id,state] of targetStates){
      if(state.startedAt==null)continue;
      const opacity=fadeOpacity(state.startedAt,now,state.fadeMode==='source'?state.duration:trailFadeDuration()),marker=liveMarkers.get(id);
      if(opacity>0){marker?.setOpacity(opacity);pending=true;}
      else {
        if(marker){targets.removeLayer(marker);liveMarkers.delete(id);selected.delete(id);removed=true;}
        trails.delete(id);
        // Keep a completed forecast while it is still in the source: repeated packets
        // must not recreate it and restart the fade. A live observation resets it.
        if(!state.present)targetStates.delete(id);
      }
    }
    trailLayer.redraw();if(removed)updateLiveStatus();
    if(pending)fadeFrame=requestAnimationFrame(animateFades);
  }
  function ensureFadeAnimation() {
    if(fadeFrame==null&&[...targetStates.values()].some(state=>state.startedAt!=null))
      fadeFrame=requestAnimationFrame(animateFades);
  }
  const TrailLayer = L.Layer.extend({
    onAdd(m) {
      this._map = m;
      this._canvas = L.DomUtil.create('canvas', 'ua-trail-canvas');
      this._canvas.style.pointerEvents = 'none';
      m.getPanes().overlayPane.appendChild(this._canvas);
      m.on('moveend zoomend resize viewreset', this.redraw, this);
      m.on('zoomstart', () => { this._canvas.style.visibility = 'hidden'; });
      this.redraw();
    },
    onRemove(m) {
      m.off('moveend zoomend resize viewreset', this.redraw, this);
      this._canvas.remove();
    },
    redraw() {
      const now=Date.now();
      for(const [id,rec] of trails){
        if(rec.disappearedAt==null)continue;
        if(fadeOpacity(rec.disappearedAt,now,rec.fadeDuration??trailFadeDuration())<=0)trails.delete(id);
      }
      const m = this._map; if (!m) return;
      const size = m.getSize(), dpr = window.devicePixelRatio || 1, c = this._canvas;
      const w = Math.max(1, Math.round(size.x * dpr)), h = Math.max(1, Math.round(size.y * dpr));
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; c.style.width = size.x + 'px'; c.style.height = size.y + 'px'; }
      const topLeft = m.containerPointToLayerPoint([0, 0]);
      L.DomUtil.setPosition(c, topLeft);
      c.style.visibility = '';
      const ctx = c.getContext('2d');
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, w, h);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (trailLimit() <= 0 || document.getElementById('map2LiveEnabled')?.checked === false) return;
      ctx.lineJoin = ctx.lineCap = 'round'; ctx.lineWidth = TRAIL_LINE_PX;
      ctx.globalAlpha = 1;
      ctx.strokeStyle = ctx.fillStyle = TRAIL_COLOR;
      const half = TRAIL_TICK_PX / 2;
      for (const rec of trails.values()) {
        const config=window.Map2TargetForms.config;
        if(rec.isPrediction && (!config.showPredicted||!config.showPredictedTracks)) continue;
        ctx.globalAlpha=fadeOpacity(rec.disappearedAt,now,rec.fadeDuration??trailFadeDuration());
        ctx.setLineDash([]);
        const points = rec.pts;
        const px = points.map(ll => { const q = m.project(L.latLng(ll), m.getZoom()).subtract(m.getPixelOrigin()); return {x: q.x - topLeft.x, y: q.y - topLeft.y}; });
        if (px.length >= 2) {
          ctx.beginPath(); ctx.moveTo(px[0].x, px[0].y);
          for (let i = 1; i < px.length; i++) ctx.lineTo(px[i].x, px[i].y);
          ctx.stroke();
        }
        for (const p of px) ctx.fillRect(p.x - half, p.y - half, TRAIL_TICK_PX, TRAIL_TICK_PX);
        if(rec.forecastPoints){
          const pixels=rec.forecastPoints.map(ll=>m.project(L.latLng(ll),m.getZoom()).subtract(m.getPixelOrigin()).subtract(topLeft));
          ctx.beginPath();ctx.moveTo(pixels[0].x,pixels[0].y);ctx.lineTo(pixels[1].x,pixels[1].y);ctx.stroke();
        }
      }
      ctx.globalAlpha=1;

    }
  });
  const trailLayer = new TrailLayer().addTo(map);
  function recordTrails(state) {
    const limit = trailLimit();
    if (limit <= 0) { trails.clear(); trailLayer.redraw(); return; }
    for (const t of state.targets) {
      if (!Number.isFinite(t.x)||!Number.isFinite(t.y)||targetExpired(t))continue;
      const coord=position(t);if(!coord.every(Number.isFinite))continue;
      let rec=trails.get(t.trackId);
      if(!rec)trails.set(t.trackId,rec={pts:[],disappearedAt:null});
      rec.isPrediction=!!t.prediction;rec.forecastPoints=null;
      // A new visitor receives history accumulated by the bridge before opening the page.
      if(Array.isArray(t.observedTrack)){
        rec.pts=t.observedTrack.filter(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))
          .slice(-limit).map(p=>position({x:p[0],y:p[1]})).filter(p=>p.every(Number.isFinite));
      }

      if(t.prediction){
        const p=t.prediction;
        if([p.fromX,p.fromY,p.toX,p.toY].every(Number.isFinite)){
          const points=[position({x:p.fromX,y:p.fromY}),position({x:p.toX,y:p.toY})];
          if(points.flat().every(Number.isFinite))rec.forecastPoints=points;
        }
      }
      if(t.prediction||t.isFading===true)continue;
      const last=rec.pts[rec.pts.length-1];
      if(last&&last[0]===coord[0]&&last[1]===coord[1])continue;
      rec.pts.push(coord);if(rec.pts.length>limit)rec.pts=rec.pts.slice(-limit);
    }
    syncTrailPresence();
    while (trails.size > 1000) trails.delete(trails.keys().next().value);
    trailLayer.redraw();
  }
  // Повзунок «Довжина треку цілі» не викликає подій — стежимо за значенням.
  let shownLimit = trailLimit();
  setInterval(() => {
    const limit = trailLimit(); if (limit === shownLimit) return;
    shownLimit = limit;
    for (const [id, rec] of trails) { if (limit <= 0) trails.delete(id); else if (rec.pts.length > limit) rec.pts = rec.pts.slice(-limit); }
    trailLayer.redraw();
  }, 250);
  function updateLiveStatus() {
    if (!snapshot || document.getElementById('map2LiveEnabled')?.checked === false) return;
    const forecastCount = targets.getLayers().filter(marker => marker.map2IsPrediction).length;
    const updatedAt = Number(snapshot.updatedAt || snapshot.serverTime);
    const ageSeconds = Number.isFinite(updatedAt) ? Math.max(0, Math.floor((Date.now() - updatedAt) / 1000)) : null;
    message(`UkraineAlarm · ${snapshotStale ? 'останні відомі позиції' : 'цілей'}: ${targets.getLayers().length} · прогнозних: ${forecastCount} · вік даних: ${ageSeconds === null ? '—' : ageSeconds + ' с'}${snapshotStale || connectionWarning ? ' · очікуємо оновлення' : ''}`);
    status.title = `Час даних джерела: ${new Date(updatedAt).toLocaleTimeString('uk-UA', {timeZone:'Europe/Kyiv'})}. Прогнозні позначки та їхні координати надані UkraineAlarm. Треки — збережена історія отриманих позицій.`;
  }
  function draw() {
    syncTrailPresence();
    if (!snapshot) { resetTargets(); return; }
    if (document.getElementById('map2LiveEnabled')?.checked === false) {
      resetTargets();
      message('UkraineAlarm · показ цілей вимкнений');return;
    }
    const settings = window._rls2Settings || {};
    const size = 34 * (window.MAP2_TARGET_SIZE_SCALES?.[settings.targetSize] || 1);
    const seen = new Set();
    for (const state of targetStates.values()) {
      const t=state.present?state.target:{...state.target,isFading:true};
      const opacity=fadeOpacity(state.startedAt,Date.now(),state.fadeMode==='source'?state.duration:trailFadeDuration());
      if(opacity<=0)continue;
      if(t.prediction && !window.Map2TargetForms.config.showPredicted) continue;
      if (!Number.isFinite(t.x) || !Number.isFinite(t.y)) continue;
      const coord = position(t);
      if (!Number.isFinite(coord[0]) || !Number.isFinite(coord[1])) continue;
      const heading = Number.isFinite(t.heading) ? t.heading : 0;
      seen.add(t.trackId);
      let marker = liveMarkers.get(t.trackId);
      if (!marker) {
        const root = document.createElement('div'); root.className = 'ua-target';
        const image = document.createElement('img'); image.alt = '';
        const label = document.createElement('span'); label.className='ua-formular';
        const leader=document.createElement('i');leader.className='ua-form-leader';leader.hidden=true;
        root.append(leader,image,label);
        marker = L.marker(coord, {icon: L.divIcon({html:root, className:'ua-marker', iconSize:[size,size], iconAnchor:[size/2,size/2]})});
        marker.map2Parts = {root, image, label, leader}; marker.map2Size = size;
        marker.map2Destination = L.latLng(coord);
        marker.map2Rotation = heading;
        marker.on('click', () => { if (selected.has(t.trackId)) selected.delete(t.trackId); else selected.add(t.trackId); draw(); });
        marker.addTo(targets); liveMarkers.set(t.trackId, marker);
      } else moveTarget(marker, coord);
      marker.setOpacity(opacity);
      const {root, image, label} = marker.map2Parts;
      root.classList.toggle('ua-last-known', snapshotStale);
      if (marker.map2Size !== size) {
        marker.setIcon(L.divIcon({html:root, className:'ua-marker', iconSize:[size,size], iconAnchor:[size/2,size/2]}));
        marker.map2Size = size;
      }
      const iconSrc = window.map2TargetIcon ? window.map2TargetIcon(t) : 'assets/nt.png';
      if (image.getAttribute('src') !== iconSrc) {
        image.src = iconSrc;
        image.onerror = () => { image.onerror = null; image.src = 'assets/nt.png'; };
      }
      marker.map2Rotation += ((heading - marker.map2Rotation) % 360 + 540) % 360 - 180;
      image.style.width = image.style.height = size + 'px'; image.style.objectFit = 'contain';
      image.style.transition = 'transform 400ms linear'; image.style.transform = 'rotate(' + marker.map2Rotation + 'deg)';
      label.style.fontSize = (settings.fontSize || 12) + 'px';
      const forms=window.Map2TargetForms;
      const sourceSpeed=(!snapshotStale&&!t.prediction&&!t.isFading)?forms.sourceSpeed(t):null;
      const estimate=currentSpeedValue(t);
      label.classList.toggle('ua-form-short',forms.config.mode!=='full'&&!selected.has(t.trackId));
      const lines=forms.rows(t,{selected:selected.has(t.trackId),stale:snapshotStale,speedKmh:sourceSpeed??estimate,approximate:sourceSpeed===null});
      label.replaceChildren(...lines.map(text=>{const row=document.createElement('div');row.className='ua-form-row';row.textContent=text;return row;}));
      label.hidden=lines.length===0;
      const color=window.Map2Symbols.colorFor(t);
      root.style.setProperty('--ua-form-color',color);
      label.style.color=(settings.colorForm||settings.spreadForms)?color:'var(--ua-form-default, #101010)';
      marker.map2TargetTypeInfo=forms.describe(t);
      marker.map2Label = t.formular || t.detectedType || 'Невизначена ціль';
      marker.map2IsPrediction = !!t.prediction;
      root.dataset.targetState=forms.state(t,{stale:snapshotStale});
      marker.getElement()?.setAttribute('aria-label',lines.join(', '));

    }
    for (const [id, marker] of liveMarkers) {
      if (!seen.has(id)) { targets.removeLayer(marker); liveMarkers.delete(id); }
    }
    trailLayer.redraw(); ensureFadeAnimation(); updateLiveStatus();
   requestAnimationFrame(layoutLabels);
  }

  window.addEventListener('map2-display-change',()=>{draw();trailLayer.redraw();});
  window.addEventListener('map2-layout-change',layoutLabels);
  if (location.protocol === 'file:') {
    clear('Для живих цілей запустіть start-map.cmd у папці map2.'); return;
  }
  if(window.Map2Config.staticHosting){message('Статична карта GitHub Pages. Живі дані потребують окремого сервера.');return;}
  message('Підключення до UkraineAlarm…');
  const stream = new EventSource('/api/targets');
  stream.addEventListener('status', event => {
    try { connectionIssue(JSON.parse(event.data).message); }
    catch { connectionIssue('Не вдалося прочитати статус підключення.'); }
  });
  function applySnapshot(packet) {
    try {
      const {state, receivedAt, sentAt, refreshIntervalMs, checkedAt} = packet;
      if (Number(receivedAt) < Number(delivery.receivedAt || 0)) return;
      delivery = {receivedAt, sentAt, checkedAt, refreshIntervalMs};
      if (!Array.isArray(state.targets)) throw Error('Invalid snapshot');
      if (state.publicTargetsEnabled === false) return clear('UkraineAlarm тимчасово призупинив показ цілей.');
      const ttl = Math.min(60000, Math.max(1000, (Number(state.snapshotTtl) || 30)*1000));
      const age = Math.max(0, Number(state.serverTime)-Number(state.updatedAt)) + Math.max(0, Date.now()-receivedAt);
      if (!Number.isFinite(age)) return connectionIssue('Некоректний час знімка.');
      const stale = age >= ttl;
      if (stale && snapshot && (!state.targets.length || Number(state.updatedAt) <= Number(snapshot.updatedAt))) {
        if (Date.now() >= expires) markSnapshotStale();
        return;
      }
      const freshnessChanged = snapshotStale !== stale;
      expires = Date.now()+ttl-age; connectionWarning = ''; snapshotStale = stale;
      if (!freshnessChanged && snapshot && snapshot.serverTime === state.serverTime && snapshot.updatedAt === state.updatedAt) {
        updateLiveStatus();
        return;
      }
      snapshot = state;
      for (const target of state.targets) if(Number.isFinite(target.x)&&Number.isFinite(target.y))
        window.Map2TargetForms.record(target,Number(state.updatedAt),position(target),!snapshotStale,(a,b)=>map.distance(a,b));
      if (!snapshotStale) recordTrails(state); draw();
    } catch { connectionIssue('Не вдалося прочитати дані UkraineAlarm.'); }
  }
  stream.addEventListener('snapshot', event => {
    try { applySnapshot(JSON.parse(event.data)); }
    catch { connectionIssue('Не вдалося прочитати дані UkraineAlarm.'); }
  });
  let refreshTimer, refreshAbort, stopped = false;
  async function requestUpdate() {
    if (stopped) return;
    const startedAt = Date.now();
    refreshAbort = new AbortController();
    const timeout = setTimeout(() => refreshAbort.abort(), 12000);
    try {
      const response = await fetch('/api/targets/refresh', {
        method: 'POST', cache: 'no-store', signal: refreshAbort.signal
      });
      const packet = await response.json();
      if (stopped) return;
      if (response.ok) applySnapshot(packet);
      else connectionIssue(packet.message || 'Очікування відповіді джерела…');
    } catch {
      if (!stopped) connectionIssue('Запит оновлення не вдався. Повторна спроба…');
    } finally {
      clearTimeout(timeout);
      if (!stopped) refreshTimer = setTimeout(requestUpdate, Math.max(0, 1000 - (Date.now() - startedAt)));
    }
  }
  void requestUpdate();
  stream.onerror = () => connectionIssue('Немає зв’язку з потоком цілей. Повторне підключення…');
  setInterval(() => {
    if (!snapshot) return;
    if (Date.now() >= expires) { markSnapshotStale(); return; }
    const remaining = snapshot.targets.filter(t => !targetExpired(t));
    if (remaining.length !== snapshot.targets.length) {
      snapshot = {...snapshot, targets: remaining};
      draw();
    } else updateLiveStatus();
  }, 1000);
  window.addEventListener('pagehide', () => {
    cancelAnimationFrame(fadeFrame);fadeFrame=null;
    stopped = true; clearTimeout(refreshTimer); refreshAbort?.abort(); stream.close(); resetTargets();
  });
  window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
})();
