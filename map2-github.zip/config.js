/* Публічні налаштування. Паролі й приватні API-ключі тут не зберігати. */
window.Map2Config = {
  // Власний браузерний ключ Jawg, обмежений доменом; без ключа є темна OSM.
  jawgAccessToken: '',
  // GitHub Pages показує статичну карту. Для власного домену Pages поставте true.
  staticHosting: location.hostname.endsWith('.github.io') || location.protocol === 'file:'
};
