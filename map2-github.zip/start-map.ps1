$ErrorActionPreference = 'Stop'

function Get-MapHealth([string]$Url) {
  try { Invoke-RestMethod "$Url/api/health" -TimeoutSec 2 } catch { $null }
}

function Test-MapPortAvailable([int]$Port) {
  $listener = New-Object System.Net.Sockets.TcpListener -ArgumentList ([System.Net.IPAddress]::Loopback), $Port
  try {
    $listener.Server.ExclusiveAddressUse = $true
    $listener.Start()
    return $true
  } catch {
    return $false
  } finally {
    $listener.Stop()
  }
}

$mapRoot = [System.IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$selectedPort = $null
$health = $null
foreach ($candidate in 17840..17939) {
  $candidateUrl = "http://127.0.0.1:$candidate"
  $candidateHealth = Get-MapHealth $candidateUrl
  if ($candidateHealth -and $candidateHealth.app -eq 'map2-ukrainealarm' -and $candidateHealth.build -eq 'alerts-v1' -and $candidateHealth.root -and [System.IO.Path]::GetFullPath([string]$candidateHealth.root).TrimEnd('\') -eq $mapRoot) {
    $selectedPort = $candidate
    $health = $candidateHealth
    break
  }
  if (-not $candidateHealth -and (Test-MapPortAvailable $candidate)) {
    $selectedPort = $candidate
    break
  }
}
if ($null -eq $selectedPort) { throw 'No available map port was found in the range 17840-17939.' }
$mapUrl = "http://127.0.0.1:$selectedPort"
if (-not $health) {
  $node = (Get-Command node -ErrorAction Stop).Source
  $previousPort = $env:MAP2_PORT
  try {
    $env:MAP2_PORT = [string]$selectedPort
    Start-Process -FilePath $node -ArgumentList ('"' + (Join-Path $PSScriptRoot 'ukrainealarm-server.cjs') + '"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
  } finally {
    $env:MAP2_PORT = $previousPort
  }
  for ($attempt = 0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Milliseconds 300
    $health = Get-MapHealth $mapUrl
    if ($health) { break }
  }
  if (-not $health -or $health.app -ne 'map2-ukrainealarm' -or -not $health.root -or [System.IO.Path]::GetFullPath([string]$health.root).TrimEnd('\') -ne $mapRoot) {
    throw "Map server could not start at $mapUrl. Node.js 22 or newer is required."
  }
}
Start-Process $mapUrl
