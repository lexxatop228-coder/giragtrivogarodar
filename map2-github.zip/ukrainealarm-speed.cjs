'use strict';
// Approximate speed between the two newest public observations, never forecasts.
const EARTH_KM = 6371.0088, MIN_INTERVAL_MS = 1;
const rad = d => d * Math.PI / 180, deg = r => r * 180 / Math.PI;
const my = lat => Math.log(Math.tan(Math.PI / 4 + rad(lat) / 2));
const west = 22.137059, east = 40.2275801, north = 52.3791473, south = 44.184598;
const scale = Math.min(260 / rad(east - west), 175 / (my(north) - my(south)));
const ox = (260 - rad(east - west) * scale) / 2, oy = (175 - (my(north) - my(south)) * scale) / 2;
function position(x, y) {
  return [deg(2 * Math.atan(Math.exp(my(north) - (y * 175 - oy) / scale)) - Math.PI / 2),
    west + deg((x * 260 - ox) / scale)];
}
function distanceKm(a, b) {
  const q = Math.sin(rad(b[0] - a[0]) / 2) ** 2
    + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(rad(b[1] - a[1]) / 2) ** 2;
  return EARTH_KM * 2 * Math.asin(Math.sqrt(Math.min(1, Math.max(0, q))));
}
function sample(target, time) {
  if (![target.x, target.y, target.cellWidth, target.cellHeight].every(Number.isFinite)
    || target.cellWidth <= 0 || target.cellHeight <= 0) return null;
  const center = position(target.x, target.y);
  const corners = [-1, 1].flatMap(dx => [-1, 1].map(dy =>
    position(target.x + dx * target.cellWidth / 2, target.y + dy * target.cellHeight / 2)));
  if (![...center, ...corners.flat()].every(Number.isFinite)) return null;
  return {time, x: target.x, y: target.y, center,
    radiusKm: Math.max(...corners.map(corner => distanceKm(center, corner)))};
}
function estimate(samples) {
  if (samples.length < 2) return {status: 'collecting', windowSeconds: 0};
  const first = samples.at(-2), last = samples.at(-1), ms = last.time - first.time;
  if (ms < MIN_INTERVAL_MS) return {status: 'collecting', windowSeconds: 0};
  const seconds = ms / 1000, windowSeconds = Math.round(seconds * 10) / 10;
  const distance = distanceKm(first.center, last.center), uncertainty = first.radiusKm + last.radiusKm;
  if (distance <= uncertainty) return {status: 'coarse-grid', windowSeconds};
  const round = value => Math.round(value * 100) / 100;
  const relativeUncertainty = uncertainty / distance;
  const valueKmh = Math.round(distance / seconds * 3600);
  const bounds = {
    minimumKmh: Math.max(0, Math.floor((distance - uncertainty) / seconds * 3600 / 10) * 10),
    maximumKmh: Math.ceil((distance + uncertainty) / seconds * 3600 / 10) * 10
  };
  return {status: relativeUncertainty > 0.25 ? 'uncertain' : 'ready', method: 'last-two-points', windowSeconds,
    valueKmh, distanceKm: round(distance), uncertaintyKm: round(uncertainty),
    relativeUncertainty: round(relativeUncertainty), ...bounds};
}
function createSpeedTracker() {
  const tracks = new Map();
  function update(state) {
    const seen = new Set(), time = Number(state.updatedAt), serverTime = Number(state.serverTime);
    const ttl = (Number(state.snapshotTtl) || 30) * 1000;
    const validTime = Number.isFinite(time) && time > 0 && Number.isFinite(serverTime)
      && serverTime >= time && serverTime - time < ttl;
    const targets = state.targets.map(target => {
      const id = target.trackId; seen.add(id);
      let result;
      if (state.publicTargetsEnabled === false || !validTime) result = {status: 'stale'};
      else if (target.prediction) result = {status: 'prediction'};
      else if (target.isFading === true) result = {status: 'fading'};
      else {
        const current = sample(target, time);
        if (!current || id == null) result = {status: 'invalid'};
        else {
          let points = tracks.get(id) || [];
          const last = points.at(-1);
          if (last && time < last.time) result = {status: 'invalid'};
          else {
            if (last && time - last.time > ttl) points = [];
            if (points.at(-1)?.time === time) points[points.length - 1] = current;
            else points.push(current);
            points = points.slice(-2);
            tracks.set(id, points);
            result = estimate(points);
          }
        }
      }
      if (['stale', 'prediction', 'fading', 'invalid'].includes(result.status)) tracks.delete(id);
      return {...target, estimatedSpeedKmh: result.status === 'ready' ? result.valueKmh : null,
        speedEstimate: result};
    });
    for (const id of tracks.keys()) if (!seen.has(id)) tracks.delete(id);
    return targets;
  }
  return {update, clear() { tracks.clear(); }};
}
module.exports = {createSpeedTracker, position, distanceKm};
