'use strict';
// Public updateMap snapshots; coordinates are matched separately by regionId.
function createAlertStore({now=Date.now,staleMs=60000}={}){
  let regions=[],action=null,receivedAt=0,checkedAt=0,failed=true;
  function apply(raw){
    try{
      let data=typeof raw==='string'?JSON.parse(raw):raw;
      for(let i=0;i<4&&data&&typeof data==='object'&&!Array.isArray(data.alerts);i++)data=data.data;
      if(!Array.isArray(data?.alerts))return false;
      const rawAction=data.actionIndex?.lastActionIndex??data.lastActionIndex??data.lastUpdate;
      if(!/^\d+$/.test(String(rawAction)))return false;
      const next=BigInt(String(rawAction));
      if(action!=null&&next<action){checkedAt=now();failed=false;return true;}
      const found=new Map();
      for(const region of data.alerts){
        const id=region?.regionId??region?.RegionId;if(id==null||String(id).length>64)continue;
        const alerts=region.activeAlerts??region.ActiveAlerts;
        if(!Array.isArray(alerts))continue;
        const air=alerts.filter(alert=>String(alert?.type??alert?.Type).toUpperCase()==='AIR');
        if(!air.length)continue;
        const red=air.some(alert=>(alert.activeAlertLevels??alert.ActiveAlertLevels??[]).some(level=>String(level?.alertLevel??level?.AlertLevel).toUpperCase()==='RED'));
        const item={id:String(id),name:String(region.regionName??region.RegionName??'').slice(0,200),level:red?'red':'yellow',startedAt:region.lastUpdate??region.LastUpdate??air[0].lastUpdate??null};
        if(!found.has(item.id)||item.level==='red')found.set(item.id,item);
      }
      regions=[...found.values()];action=next;receivedAt=checkedAt=now();failed=false;return true;
    }catch{return false;}
  }
  function snapshot(){return {source:'UkraineAlarm',regions,actionIndex:action?.toString()??null,receivedAt,checkedAt,available:action!=null,stale:failed||!checkedAt||now()-checkedAt>staleMs};}
  return {apply,snapshot,unavailable(){failed=true;}};
}
module.exports={createAlertStore};
