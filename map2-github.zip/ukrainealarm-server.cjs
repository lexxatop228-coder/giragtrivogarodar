'use strict';
// Local bridge for the public UkraineAlarm feed. No API key or saved token.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
require('./ukrainealarm-wire.cjs');
const {createSpeedTracker} = require('./ukrainealarm-speed.cjs');
const speedTracker = createSpeedTracker();
const {createTrailTracker}=require('./ukrainealarm-trails.cjs');
const dataDir=process.env.MAP2_DATA_DIR;
const trailTracker=createTrailTracker(dataDir?{
  storagePath:path.join(dataDir,'tracks.json'),retentionMs:24*60*60*1000
}:{});
for(const signal of ['SIGTERM','SIGINT'])process.once(signal,()=>{
  void trailTracker.close().finally(()=>process.exit(0));
});
const {createAlertStore}=require('./ukrainealarm-alerts.cjs');
const alertStore=createAlertStore();
const ALERT_REFRESH_MS=15000;
let alertsLastCheck=0;
let openingConnection=false;
const clients = new Set(), pending = new Map();
const REFRESH_INTERVAL_MS = 1000;
let socket, reconnect, polling, opening, reader, lastState, refreshHistory, checkedAt = 0, serial = 0, generation = 0, revision = 0;
const port = Number(process.env.MAP2_PORT || 17840);
function send(client, event, data) { client.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); }
function broadcast(event, data) { for (const client of clients) send(client, event, data); }
function snapshotEnvelope() {
  // Keep the original reception time: a repeated delivery is not a new observation.
  return {...lastState, sentAt: Date.now(), checkedAt, refreshIntervalMs: REFRESH_INTERVAL_MS};
}
function targetData(target) {
  // h means hits, not altitude. Source telemetry stays separate from estimates.
  const labelNumber = typeof target.formular === 'string'
    ? target.formular.match(/^\s*(\d+)(?=\s|$)/)?.[1] : null;
  return {...target,
    targetNumber: target.targetNumber ?? labelNumber ?? null,
    targetNumberSource: target.targetNumber != null ? 'source-field' : labelNumber != null ? 'source-label' : null,
    altitude: target.altitude ?? null,
    speed: target.speed ?? null
  };
}
function publish(data) {
  const decoded = reader(data);
  if (!decoded) return;
  const state = {...decoded, targets: trailTracker.update({...decoded,targets:speedTracker.update(decoded)}).map(targetData)};
  revision++;
  lastState = {state, receivedAt: Date.now()};
  broadcast('snapshot', snapshotEnvelope());
}
function command(method, params) {
  return new Promise((resolve, reject) => {
    const id = ++serial;
    const timer = setTimeout(() => { pending.delete(id); reject(Error('Command timeout')); }, 10000);
    pending.set(id, {resolve, reject, timer});
    try { socket.send(JSON.stringify({id, ...(method ? {method} : {}), params})); }
    catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
  });
}
function disconnect() {
  generation++;
  clearInterval(polling); clearTimeout(opening); clearTimeout(reconnect);
  const old = socket; socket = null;
  if (old) old.close();
  for (const item of pending.values()) { clearTimeout(item.timer); item.reject(Error('Disconnected')); }
  pending.clear(); speedTracker.clear(); lastState = null; refreshHistory = null; checkedAt = 0;
}
function unavailable() {
  alertStore.unavailable();
  disconnect();
  broadcast('status', {message: 'Немає зв’язку з UkraineAlarm. Повторне підключення…'});
  reconnect = setTimeout(connect, 5000);
}
async function connect() {
  if(openingConnection||socket)return;
  openingConnection=true;
  try{await connectSource();}finally{openingConnection=false;}
}
async function connectSource() {
  const run = ++generation;
  broadcast('status', {message: 'Підключення до UkraineAlarm…'});
  try {
    const response = await fetch('https://map.ukrainealarm.com/', {signal: AbortSignal.timeout(15000)});
    if (!response.ok) throw Error('Source HTTP ' + response.status);
    const html = await response.text();
    if (run !== generation) return;
    function input(id) {
      const tag = [...html.matchAll(/<input\b[^>]*>/gi)].map(m => m[0]).find(t => t.includes(`id="${id}"`));
      return tag?.match(/value="([^"]*)"/)?.[1]?.replace(/&amp;/g, '&');
    }
    const url = input('centrifugo-url'), token = input('centrifugo-token');
    const channel = html.match(/data-target-centrifugo-channel="([^"]+)"/)?.[1];
    if (!url?.startsWith('wss://ws.ukrainealarm.com/') || !token || !channel) throw Error('Public configuration unavailable');
    const ws = socket = new WebSocket(url);
    reader = globalThis.detailTargetWire.createReader();
    ws.addEventListener('message', event => {
      if (run !== generation) return;
      try {
        for (const line of String(event.data).split('\n').filter(Boolean)) {
          const message = JSON.parse(line);
          if (message.id && pending.has(message.id)) {
            const item = pending.get(message.id); pending.delete(message.id); clearTimeout(item.timer);
            if (message.error) item.reject(Error('Protocol ' + message.error.code)); else item.resolve(message.result);
          } else if(message.result?.channel==='updateMap'){
            alertStore.apply(message.result.data?.data??message.result.data);
          } else if (message.result?.channel === channel && message.result?.data?.data) {
            publish(message.result.data.data);
          }
        }
      } catch { unavailable(); }
    });
    ws.addEventListener('close', () => { if (run === generation) unavailable(); });
    ws.addEventListener('error', () => { if (run === generation) unavailable(); });
    opening = setTimeout(() => { if (run === generation) unavailable(); }, 15000);
    ws.addEventListener('open', async () => {
      clearTimeout(opening);
      try {
        await command(0, {token}); await command(1, {channel});
        let alertsInFlight=null,alertsSubscribed=false;
        async function alertHistory(){
          if(run!==generation)return false;if(alertsInFlight)return alertsInFlight;
          alertsLastCheck=Date.now();
          alertsInFlight=(async()=>{
            try{
              if(!alertsSubscribed){await command(1,{channel:'updateMap'});if(run!==generation)return false;alertsSubscribed=true;}
              const result=await command(6,{channel:'updateMap',limit:1});if(run!==generation)return false;
              const latest=result?.publications?.at(-1);
              if(!latest||!alertStore.apply(latest.data))alertStore.unavailable();
              return !!latest;
            }catch{if(run===generation){alertsSubscribed=false;alertStore.unavailable();}return false;}
            finally{alertsInFlight=null;}
          })();return alertsInFlight;
        }
        void alertHistory();
        let inFlight = null;
        function history() {
          if (run !== generation) return Promise.resolve(false);
          if (inFlight) return inFlight;
          // Browser requests and scheduled checks share a single upstream request.
          inFlight = (async () => {
            const before = revision;
            try {
              const result = await command(6, {channel, limit: 1});
              if (run !== generation) return false;
              checkedAt = Date.now();
              if (before !== revision) return true;
              const publication = result?.publications?.at(-1);
              if (publication) publish(publication.data);
              else { lastState = null; broadcast('status', {message: 'UkraineAlarm поки не надає даних про цілі.'}); }
              return true;
            } catch {
              if (run === generation) unavailable();
              return false;
            } finally { inFlight = null; }
          })();
          return inFlight;
        }
        refreshHistory = history;
        await history();
        if (run === generation) polling = setInterval(()=>{void history();if(Date.now()-alertsLastCheck>=ALERT_REFRESH_MS)void alertHistory();}, REFRESH_INTERVAL_MS);
      } catch { if (run === generation) unavailable(); }
    });
  } catch { if (run === generation) unavailable(); }
}
const mime = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.geojson':'application/geo+json', '.png':'image/png', '.svg':'image/svg+xml', '.woff2':'font/woff2'};
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  if(url.pathname==='/api/alerts'){
    if(req.method!=='GET'){res.writeHead(405,{'Allow':'GET'});return res.end();}
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
    return res.end(JSON.stringify(alertStore.snapshot()));
  }
  if (url.pathname === '/api/targets/refresh') {
    if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}`) { res.writeHead(403); return res.end(); }
    if (req.method !== 'POST') { res.writeHead(405, {'Allow':'POST'}); return res.end(); }
    const refresh = refreshHistory;
    const confirmed = refresh ? await refresh() : false;
    if (res.destroyed) return;
    res.writeHead(confirmed && lastState ? 200 : 503, {'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store'});
    return res.end(JSON.stringify(confirmed && lastState ? snapshotEnvelope() : {message:'Очікування свіжої відповіді UkraineAlarm…'}));
  }
  if (url.pathname === '/api/targets') {
    if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}`) { res.writeHead(403); return res.end(); }
    res.writeHead(200, {'Content-Type':'text/event-stream', 'Cache-Control':'no-store', 'Connection':'keep-alive'});
    clients.add(res);
    send(res, 'status', {message:'Очікування даних UkraineAlarm…'});
    if (lastState) send(res, 'snapshot', snapshotEnvelope());
    if (clients.size === 1 && !socket) void connect();
    const heartbeat = setInterval(() => {
      if (lastState) send(res, 'snapshot', snapshotEnvelope());
      else res.write(': heartbeat\n\n');
    }, REFRESH_INTERVAL_MS);
    req.on('close', () => { clearInterval(heartbeat); clients.delete(res); });
    return;
  }
  if (url.pathname === '/api/health') { res.writeHead(200, {'Content-Type':'application/json'}); return res.end(JSON.stringify({app:'map2-ukrainealarm',build:'alerts-v1',root:__dirname,pid:process.pid,refreshIntervalMs:REFRESH_INTERVAL_MS})); }
  let filename;
  try { filename = path.resolve(__dirname, '.' + decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname)); }
  catch { res.writeHead(400); return res.end(); }
  const type = mime[path.extname(filename)];
  if (!filename.startsWith(__dirname + path.sep) || !type) { res.writeHead(403); return res.end(); }
  fs.readFile(filename, (error, data) => {
    if (error) { res.writeHead(404); return res.end(); }
    res.writeHead(200, {'Content-Type':type + (type.startsWith('text/') ? '; charset=utf-8' : ''), 'Cache-Control':'no-cache'}); res.end(data);
  });
}).listen(port, '127.0.0.1', () => {console.log(`Карта 2: http://127.0.0.1:${port}/`);void connect();});
